"use strict";
const { vec3 } = glMatrix;

var canvas;
var gl;
var program;
var points = [];
var numTimesToSubdivide = 1; // 默认剖分层次


// 页面加载时初始化：仅做WebGL环境配置，不直接生成图形
window.onload = function initTriangles() {
    canvas = document.getElementById("gl-canvas");
    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL isn't available");
        return;
    }

    // 1. 配置WebGL基础环境（视口、背景色）
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0); // 白色背景

    // 2. 加载并编译着色器程序（仅执行一次，复用）
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // 3. 页面加载时默认绘制层次1的图形
    updateGasket();
};


function updateGasket() {
    // 步骤1：读取输入框的剖分层次（带容错处理）
    const inputElem = document.getElementById("level-input");
    // 确保值在0-7之间：非数字/超范围时取默认值1
    numTimesToSubdivide = Math.min(7, Math.max(0, parseInt(inputElem.value) || 1));
    // 修正输入框显示（避免用户看到无效值）
    inputElem.value = numTimesToSubdivide;

    // 步骤2：生成对应层次的三角形顶点数据
    generateTriangleData(numTimesToSubdivide);

    // 步骤3：将顶点数据传入GPU并渲染
    renderTriangles();
}


// 新增：生成三角形顶点数据（抽离原逻辑，便于复用）
function generateTriangleData(level) {
    // 清空之前的顶点数据（避免叠加）
    points = [];

    // 初始三角形的三个顶点（与原代码一致）
    var vertices = [
        -1, -1, 0,
        0, 1, 0,
        1, -1, 0
    ];
    var u = vec3.fromValues(vertices[0], vertices[1], vertices[2]);
    var v = vec3.fromValues(vertices[3], vertices[4], vertices[5]);
    var w = vec3.fromValues(vertices[6], vertices[7], vertices[8]);

    // 递归细分三角形（使用当前输入的层次）
    divideTriangle(u, v, w, level);
}


// 原函数：存储单个三角形的三个顶点
function triangle(a, b, c) {
    points.push(a[0], a[1], a[2]);
    points.push(b[0], b[1], b[2]);
    points.push(c[0], c[1], c[2]);
}


// 原函数：递归细分三角形
function divideTriangle(a, b, c, count) {
    // 递归终止：层次为0时，直接存储当前三角形
    if (count == 0) {
        triangle(a, b, c);
    } else {
        // 计算三条边的中点（线性插值：中点 = (起点+终点)/2）
        var ab = vec3.create();
        vec3.lerp(ab, a, b, 0.5);
        var bc = vec3.create();
        vec3.lerp(bc, b, c, 0.5);
        var ca = vec3.create();
        vec3.lerp(ca, c, a, 0.5);

        // 递归细分三个外围小三角形（剔除中间三角形，生成谢尔宾斯基结构）
        divideTriangle(a, ab, ca, count - 1);
        divideTriangle(b, bc, ab, count - 1);
        divideTriangle(c, ca, bc, count - 1);
    }
}


// 修改：渲染函数（复用着色器程序，仅更新数据）
function renderTriangles() {
    // 1. 清空画布（白色背景）
    gl.clear(gl.COLOR_BUFFER_BIT);

    // 2. 创建并绑定顶点缓冲区（每次更新数据需重新绑定）
    var vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    // 将顶点数据传入GPU（Float32Array适配WebGL数据格式）
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(points), gl.STATIC_DRAW);

    // 3. 关联着色器变量与缓冲区数据（与原代码一致）
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // 4. 绘制三角形：每次绘制的顶点数 = 总坐标数 / 3（每个顶点3个坐标）
    gl.drawArrays(gl.TRIANGLES, 0, points.length / 3);
}