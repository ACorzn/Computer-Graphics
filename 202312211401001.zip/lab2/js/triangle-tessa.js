"use strict";
const { vec3 } = glMatrix;

// 全局变量：扩展原结构，新增复用资源
var canvas;
var gl;
var program;
var points = []; // 存储线框顶点数据

/** 原参数：改为可通过控件动态修改 */
var numTimesToSubdivide = 0; // 剖分层次
var theta = 60; // 旋转角度（°）
var twist = false; // 是否启用扭曲
var radius = 1.0; // 初始三角形外接圆半径


// 页面加载时初始化：仅配置WebGL环境，不直接生成图形
window.onload = function initTriangles() {
    canvas = document.getElementById("gl-canvas");
    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL isn't available");
        return;
    }

    // 1. 配置WebGL基础环境
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0); // 白色背景

    // 2. 加载并编译着色器程序（仅执行一次，复用）
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // 3. 页面加载时默认绘制（层次0、角度60°、无扭曲）
    updateTessellation();
};


// 新增：核心函数——根据控件值更新并绘制线框图案
function updateTessellation() {
    // 步骤1：读取所有控件值，更新全局参数
    // 1.1 剖分层次（0-7，容错处理）
    const levelInput = document.getElementById("subdivide-level");
    numTimesToSubdivide = Math.min(7, Math.max(0, parseInt(levelInput.value) || 0));
    levelInput.value = numTimesToSubdivide; // 修正输入显示

    // 1.2 旋转角度（0-360°，容错处理）
    const thetaInput = document.getElementById("rotate-theta");
    theta = Math.min(360, Math.max(0, parseInt(thetaInput.value) || 60));
    thetaInput.value = theta; // 修正输入显示

    // 1.3 扭曲开关（布尔值）
    const twistInput = document.getElementById("twist-switch");
    twist = twistInput.checked;

    // 步骤2：生成对应参数的线框顶点数据
    generateTessData();

    // 步骤3：将数据传入GPU并渲染线框（线框模式：gl.LINES）
    renderTriangles();
}


// 新增：生成线框顶点数据（抽离原逻辑，依赖全局参数）
function generateTessData() {
    // 清空之前的顶点数据（避免新旧数据叠加）
    points = [];

    // 1. 计算初始三角形的三个顶点（外接圆半径radius，角度90°、210°、-30°）
    var vertices = [
        radius * Math.cos(90 * Math.PI / 180.0), radius * Math.sin(90 * Math.PI / 180.0), 0,
        radius * Math.cos(210 * Math.PI / 180.0), radius * Math.sin(210 * Math.PI / 180.0), 0,
        radius * Math.cos(-30 * Math.PI / 180.0), radius * Math.sin(-30 * Math.PI / 180.0), 0
    ];

    // 2. 转换为vec3向量（便于后续细分计算）
    var u = vec3.fromValues(vertices[0], vertices[1], vertices[2]);
    var v = vec3.fromValues(vertices[3], vertices[4], vertices[5]);
    var w = vec3.fromValues(vertices[6], vertices[7], vertices[8]);

    // 3. 递归细分三角形，生成线框数据
    divideTriangle(u, v, w, numTimesToSubdivide);
}


// 原函数：生成单个三角形的线框数据（不变，依赖全局参数theta、twist）
function tessellaTriangle(a, b, c) {
    var zerovec3 = vec3.create();
    vec3.zero(zerovec3);
    var radian = theta * Math.PI / 180.0; // 角度转弧度

    var a_new = vec3.create();
    var b_new = vec3.create();
    var c_new = vec3.create();

    // 无扭曲：整体绕原点旋转radian角度
    if (twist == false) {
        vec3.rotateZ(a_new, a, zerovec3, radian);
        vec3.rotateZ(b_new, b, zerovec3, radian);
        vec3.rotateZ(c_new, c, zerovec3, radian);
    } 
    // 有扭曲：按顶点到原点的距离动态旋转（距离越远，旋转角度越大）
    else {
        var d_a = Math.sqrt(a[0] * a[0] + a[1] * a[1]); // a到原点的距离
        var d_b = Math.sqrt(b[0] * b[0] + b[1] * b[1]); // b到原点的距离
        var d_c = Math.sqrt(c[0] * c[0] + c[1] * c[1]); // c到原点的距离

        // 手动计算2D旋转（x'=x*cosθ - y*sinθ；y'=x*sinθ + y*cosθ）
        vec3.set(a_new, 
            a[0] * Math.cos(d_a * radian) - a[1] * Math.sin(d_a * radian), 
            a[0] * Math.sin(d_a * radian) + a[1] * Math.cos(d_a * radian), 
            0
        );
        vec3.set(b_new, 
            b[0] * Math.cos(d_b * radian) - b[1] * Math.sin(d_b * radian), 
            b[0] * Math.sin(d_b * radian) + b[1] * Math.cos(d_b * radian), 
            0
        );
        vec3.set(c_new, 
            c[0] * Math.cos(d_c * radian) - c[1] * Math.sin(d_c * radian), 
            c[0] * Math.sin(d_c * radian) + c[1] * Math.cos(d_c * radian), 
            0
        );
    }

    // 线框模式：存储三角形的三条边（每条边2个顶点，共6个顶点）
    points.push(a_new[0], a_new[1], a_new[2]); // 边1：a→b
    points.push(b_new[0], b_new[1], b_new[2]);
    points.push(b_new[0], b_new[1], b_new[2]); // 边2：b→c
    points.push(c_new[0], c_new[1], c_new[2]);
    points.push(c_new[0], c_new[1], c_new[2]); // 边3：c→a
    points.push(a_new[0], a_new[1], a_new[2]);
}


// 原函数：递归细分三角形（不变，细分后生成线框）
function divideTriangle(a, b, c, count) {
    // 递归终止：层次为0时，直接生成当前三角形的线框
    if (count == 0) {
        tessellaTriangle(a, b, c);
    } else {
        // 计算三条边的中点（线性插值：中点 = (起点+终点)/2）
        var ab = vec3.create();
        vec3.lerp(ab, a, b, 0.5);
        var bc = vec3.create();
        vec3.lerp(bc, b, c, 0.5);
        var ca = vec3.create();
        vec3.lerp(ca, c, a, 0.5);

        // 递归细分4个新三角形（与原代码一致：包含中心三角形，生成密集线框）
        divideTriangle(a, ab, ca, count - 1);
        divideTriangle(ab, b, bc, count - 1);
        divideTriangle(ca, bc, c, count - 1);
        divideTriangle(ab, bc, ca, count - 1);
    }
}


// 修改：渲染线框图案（复用着色器程序，线框模式gl.LINES）
function renderTriangles() {
    // 1. 清空画布（白色背景）
    gl.clear(gl.COLOR_BUFFER_BIT);

    // 2. 绑定顶点数据缓冲区
    var vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(points), gl.STATIC_DRAW);

    // 3. 关联顶点位置属性（与着色器的vPosition对应）
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // 4. 线框模式绘制：gl.LINES（每2个顶点构成一条线段）
    gl.drawArrays(gl.LINES, 0, points.length / 3);
}