"use strict";
/* import vec3 from glMatrix */
const { vec3 } = glMatrix;

// 全局变量：扩展原结构，新增复用资源
var gl;
var canvas;
var program; // 新增：存储着色器程序（仅创建一次）
var points = []; // 存储顶点坐标
var colors = []; // 存储顶点颜色
var numTimesToSubdivide = 3; // 默认剖分层次


// 页面加载时初始化：仅配置WebGL环境，不直接生成图形
window.onload = function init() {
    canvas = document.getElementById("gl-canvas");
    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL isn't available");
        return;
    }

    // 1. 配置WebGL基础环境
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0); // 白色背景
    gl.enable(gl.DEPTH_TEST); // 启用深度测试（3D图形必备，解决遮挡问题）

    // 2. 加载并编译着色器程序（仅执行一次，复用）
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // 3. 页面加载时默认绘制层次3的3D四面体
    update3DGasket();
};


// 新增：核心函数——根据输入层次更新并绘制3D图形
function update3DGasket() {
    // 步骤1：读取输入框的剖分层次（带容错处理）
    const inputElem = document.getElementById("level-input");
    // 容错逻辑：非数字/超范围时取默认值3
    numTimesToSubdivide = Math.min(7, Math.max(0, parseInt(inputElem.value) || 3));
    // 修正输入框显示（避免用户看到无效值）
    inputElem.value = numTimesToSubdivide;

    // 步骤2：生成对应层次的3D顶点和颜色数据
    generate3DData(numTimesToSubdivide);

    // 步骤3：将数据传入GPU并渲染3D图形
    render3DGasket();
}


// 新增：生成3D四面体的顶点和颜色数据（抽离原逻辑）
function generate3DData(level) {
    // 清空之前的数据（避免新旧数据叠加）
    points = [];
    colors = [];

    // 初始3D四面体的4个顶点（正四面体，边长相等）
    var vertices = [
        0.0000, 0.0000, -1.0000,  // 顶点1：底部
        0.0000, 0.9428, 0.3333,   // 顶点2：顶部
        -0.8165, -0.4714, 0.3333, // 顶点3：左下
        0.8165, -0.4714, 0.3333   // 顶点4：右下
    ];

    // 转换为vec3向量（便于后续插值计算）
    var t = vec3.fromValues(vertices[0], vertices[1], vertices[2]);
    var u = vec3.fromValues(vertices[3], vertices[4], vertices[5]);
    var v = vec3.fromValues(vertices[6], vertices[7], vertices[8]);
    var w = vec3.fromValues(vertices[9], vertices[10], vertices[11]);

    // 递归细分四面体（使用当前输入的层次）
    divideTetra(t, u, v, w, level);
}


// 原函数：生成单个三角形的顶点和颜色（不变）
function triangle(a, b, c, color) {
    // 4种基础颜色（红、绿、蓝、黑），对应4个面
    var baseColor = [
        1.0, 0.0, 0.0, 1.0,  // 颜色0：红色
        0.0, 1.0, 0.0, 1.0,  // 颜色1：绿色
        0.0, 0.0, 1.0, 1.0,  // 颜色2：蓝色
        0.0, 0.0, 0.0, 1.0   // 颜色3：黑色
    ];

    // 为三角形的3个顶点分别添加颜色和坐标
    // 顶点a
    for (var k = 0; k < 4; k++) colors.push(baseColor[color * 4 + k]);
    for (var k = 0; k < 3; k++) points.push(a[k]);
    // 顶点b
    for (var k = 0; k < 4; k++) colors.push(baseColor[color * 4 + k]);
    for (var k = 0; k < 3; k++) points.push(b[k]);
    // 顶点c
    for (var k = 0; k < 4; k++) colors.push(baseColor[color * 4 + k]);
    for (var k = 0; k < 3; k++) points.push(c[k]);
}


// 原函数：生成四面体的4个面（每个面是一个三角形，对应不同颜色）
function tetra(a, b, c, d) {
    triangle(a, c, b, 0); // 面1：红色
    triangle(a, c, d, 1); // 面2：绿色
    triangle(a, b, d, 2); // 面3：蓝色
    triangle(b, c, d, 3); // 面4：黑色
}


// 原函数：递归细分四面体（仅修正vec3.lerp调用方式，避免冗余前缀）
function divideTetra(a, b, c, d, count) {
    // 递归终止：层次为0时，直接生成当前四面体
    if (count == 0) {
        tetra(a, b, c, d);
    } else {
        // 计算6条棱的中点（线性插值：中点 = (起点+终点)/2）
        var ab = vec3.create();
        vec3.lerp(ab, a, b, 0.5); // 移除冗余的glMatrix.前缀（已解构vec3）
        var ac = vec3.create();
        vec3.lerp(ac, a, c, 0.5);
        var ad = vec3.create();
        vec3.lerp(ad, a, d, 0.5);
        var bc = vec3.create();
        vec3.lerp(bc, b, c, 0.5);
        var bd = vec3.create();
        vec3.lerp(bd, b, d, 0.5);
        var cd = vec3.create();
        vec3.lerp(cd, c, d, 0.5);

        count--; // 细分次数减1

        // 递归细分4个新的子四面体（剔除中心四面体，生成3D分形结构）
        divideTetra(a, ab, ac, ad, count);
        divideTetra(ab, b, bc, bd, count);
        divideTetra(ac, bc, c, cd, count);
        divideTetra(ad, bd, cd, d, count);
    }
}


// 修改：渲染3D图形（复用着色器程序，仅更新数据）
function render3DGasket() {
    // 1. 清空颜色缓冲区和深度缓冲区（3D渲染必须清空深度缓冲区）
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // 2. 处理顶点数据缓冲区
    var vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(points), gl.STATIC_DRAW);
    // 关联顶点位置属性（与着色器的vPosition对应）
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // 3. 处理颜色数据缓冲区
    var cBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);
    // 关联顶点颜色属性（与着色器的aColor对应）
    var aColor = gl.getAttribLocation(program, "aColor");
    gl.vertexAttribPointer(aColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aColor);

    // 4. 绘制3D四面体：每个三角形3个顶点，总数量 = 顶点坐标总数 / 3
    gl.drawArrays(gl.TRIANGLES, 0, points.length / 3);
}